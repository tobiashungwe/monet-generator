from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import numpy as np
import uvicorn
from io import BytesIO
import os

app = FastAPI()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Adjust this as needed
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Paths to the unzipped models
model_paths = {
    "monet_generator": 'models/monet_generator',
    "real_generator": 'models/real_generator'
}

# Load models
models_dict = {
    "monet_generator": load_model(model_paths["monet_generator"]),
    "real_generator": load_model(model_paths["real_generator"])
}

@app.post("/predict/")
async def predict(model_name: str, file: UploadFile = File(...)):
    # Load image
    contents = await file.read()
    img = image.load_img(BytesIO(contents), target_size=(224, 224))
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0) / 255.0

    # Predict using the selected model
    model = models_dict.get(model_name)
    if model is None:
        return {"error": "Model not found"}

    prediction = model.predict(img_array)
    result = prediction.tolist()

    return {"prediction": result}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
